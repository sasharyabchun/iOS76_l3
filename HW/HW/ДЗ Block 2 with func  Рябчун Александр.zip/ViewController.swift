//
//  ViewController.swift
//  ios-76 ios-76 is076-l2-hw01
//
//  Created by Alexandr on 18.12.2019.
//  Copyright © 2019 Alexandr. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        task1()
        task2()
        task3()
        task4()
    }
    
    //Задача 1. Остров Манхэттен был приобретен поселенцами за $24 в 1826 г. Каково было бы в настоящее время состояниеих счета, если бы эти 24 доллара были помещены тогда в банк под 6% годового дохода?
    func task1() {
        print("Task #1")
        
        let startYear = 1826
        let date = Date()
        let finishYear = Calendar.current.component(.year, from: date)
        let payment: Double = 24
        let tariff: Double = 0.06 //6% годового дохода
        
        print("Dates from \(startYear) to \(finishYear)")
        print("Payment: \(payment). Tariff: \(Int(tariff * 100))%")
        	
        let sumOnAccount:Double = calcSunOnAccount(payment: payment, startYear: startYear, finishYear: finishYear, tariff: tariff)
        
        print("Now they would have \(Int(sumOnAccount)) dollars")
        print("Task #1 is finished\n")
    }
    
    func calcSunOnAccount(payment: Double, startYear: Int, finishYear: Int, tariff: Double) -> Double {
        var sumOnAccount:Double = payment
        for _ in startYear...finishYear { // I am not sure about start year. 1826 or 1827
            sumOnAccount += sumOnAccount * tariff
        }
        return sumOnAccount
    }

    //Задача 2. Ежемесячная стипендия студента составляет 700 гривен, а расходы на проживание превышают ее и составляют 1000 грн. в месяц. Рост цен ежемесячно увеличивает расходы на 3%. Определить, какую нужно иметь сумму денег, чтобы прожить учебный год (10 месяцев), используя только эти деньги и стипендию.
    func task2() {
        print("Task #2")
        
        let grant: Double = 700
        let spending: Double = 1000
        let inflation: Double = 0.03 //Рост цен ежемесячно увеличивает расходы на 3%
        let duration = 10 //чебный год (10 месяцев)
        
        let result: Double = calcNeededMoney(grant: grant, spending: spending, duration: duration, inflation: inflation)
        
        print("Student needs \(abs(Int(result)))uah for \(duration) months")
        
        print("Task #2 is finished\n")
    }
    
    func calcNeededMoney(grant: Double, spending: Double, duration: Int, inflation: Double)
        -> Double {
        var result: Double = grant - spending //first month without inflation
        var newSpending = spending
        for _ in 1..<duration {
            newSpending += newSpending * inflation
            result += grant - newSpending
        }
        return result
    }

    //Задача 3. У студента имеются накопления 2400 грн. Ежемесячная стипендия составляет 700 гривен, а расходы на проживание превышают ее и составляют 1000 грн. в месяц. Рост цен ежемесячно увеличивает расходы на 3%. Определить, сколько месяцев сможет прожить студент, используя только накопления и стипендию.
    func task3() {
        print("Task #3")
        
        let rest: Double = 2400
        let grant: Double = 700
        let spending: Double = 1000
        let inflation: Double = 0.03 //Рост цен ежемесячно увеличивает расходы на 3%
        let duration = calcMonthLeft(rest: rest, grant: grant, spending: spending, inflation: inflation)
        
        print("The student can live \(duration) months in such conditions")
        
        print("Task #3 is finished\n")
    }
    
    func calcMonthLeft(rest: Double, grant: Double, spending: Double, inflation: Double) -> Int {
        var newRest = rest
        var newSpending = spending
        
        var duration = 0
        while newRest > 0 { //possible inifinite loop
            duration += 1
            newRest = newRest + grant - newSpending
            newSpending += newSpending * inflation //spending for next month
        }
        
        return duration
    }
    
    //Задача 4. 2хзначную цело численную переменную типа 25, 41, 12. После выполнения вашей программы у вас в другой переменной должно лежать это же число только задом на перед 52, 14, 21
    func task4() {
        print("Task #4")
        
        var number = 0
        while number % 10 == 0 { // 0-ending is forbidden
            number = Int.random(in: 11...Int.max)
        }
        
        print("Number is \(number)")
        
        print("Reverse is \(reverseNumber(number: number))")
        
        print("Task #4 is finished\n")
    }
    
    func reverseNumber(number: Int) -> Int {
        var rest = number
        var result = 0
        
        while rest > 10 {
            result = result * 10 + rest % 10
            rest = rest / 10
        }
        result = result * 10 + rest
        
        return result
    }
}

